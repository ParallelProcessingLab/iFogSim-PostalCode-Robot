package org.fog.federat;

import java.util.Random;

import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.utils.distribution.DeterministicDistribution;

public class MNISTSensor extends Sensor {
    private static final int NUM_CLASSES = 10; // اعداد ۰ تا ۹ در MNIST
    private Random random = new Random();

    public MNISTSensor(String name, String sensorType) {
        super(name, sensorType, new DeterministicDistribution(5)); // هر ۵ ثانیه یک داده تولید می‌کند
    }

    @Override
    public void transmit() {
        // تولید یک تصادفی از MNIST (شبیه‌سازی شده)
        int label = random.nextInt(NUM_CLASSES); // لیبل تصادفی (۰ تا ۹)
        float[] pixels = generateRandomMNISTPixels(); // پیکسل‌های تصادفی (شبیه‌سازی شده)
        
        // ایجاد Tuple حاوی داده‌های MNIST
        Tuple tuple = new Tuple(getId(), getId(), getDirection(), getSensorType(), getDataSize());
        tuple.setTupleData(new MNISTData(label, pixels));
        
        // ارسال Tuple به ماژول پردازشگر
        sendTuple(tuple);
    }

    private float[] generateRandomMNISTPixels() {
        float[] pixels = new float[28 * 28]; // ابعاد تصاویر MNIST (28x28)
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = random.nextFloat(); // مقادیر پیکسل‌ها بین ۰ تا ۱
        }
        return pixels;
    }
}